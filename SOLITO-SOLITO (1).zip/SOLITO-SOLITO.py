######################################################################################################
############################## PROGETTO ESAME ALGORITMI ##############################################
######################################################################################################


## QUESTION 1:
## DOMANDA 1: 
## Le 10 località da cui partono più viaggi, ovvero attraversate dalla maggior parte dei viaggi.
## Nello specifico, la domanda è la seguente:
## "Calcola e restituisci le 10 località con il maggior numero di partenze
## per una determinata città e un periodo di tempo specificato (giornaliero e settimanale)."

## USO LIBRERIA PANDAS ##

import pandas as pd
import os  #libreria per interagire piu velocemente con il sistema operativo
import time #serve per il tempo di esecuzione

listacitta = ["adelaide", "belfast", "berlin", "bordeaux", "brisbane", "canberra", "detroit", "dublin", "grenoble", "helsinki", "kuopio", "lisbon", "luxembourg", "melbourne", "nantes", "palermo", "paris", "prague", "rennes", "rome", "sydney", "toulouse", "turku", "venice", "winnipeg"]

# Base path dove sono salvati i file csv delle citta
path_cartella = "C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject"

def top_10_partenze(citta, base_path, periodo):

    current_city_path = os.path.join(base_path, citta) #percorso da basepath alla cartella della citta
    file_path_nodes = os.path.join(current_city_path, "network_nodes.csv") #percorso da cartella citta a file dei nodi
    dataset = pd.read_csv(file_path_nodes, sep=';')
    
    #PRIMO PROBLEMA: PIU STOP ID SONO ASSOCIATI ALLA STESSA FERMATA/DESTINAZIONE.
    #IL PROBLEMA è STATO RISOLTO COSTRUENDO DEGLI ID UNICI/COMPOSITI, UNO PER OGNI FERMATA.

    # CREO UN DIZIONARIO CHE MAPPA GLI STOP ID ORIGINALI AI NOMI DELLE CITTA: chiave=stop id; valore=citta
    id_to_name_map = pd.Series(dataset['name'].values, index=dataset['stop_I']).to_dict() #fondamentale nella fase successiva

    # CREO UN SECONDO DIZIONARIO CHE ASSOCIA UNA CITTA/DESTINAZIONE A OGNI ID UNICO :
    unique_names = dataset['name'].unique() # Trova i nomi unici delle località (eliminando i duplicati)
    name_to_composite_id_map = {name: idx for idx, name in enumerate(unique_names)} #creo dizionario
    #che associa ai nomi gli gli stop id unici: chiave=nomi fermate; valore=stop id unico
    composite_id_to_name_map = {idx: name for name, idx in name_to_composite_id_map.items()} #e viceversa
    #chiave= stop id unico; valore=nomi fermate

    # CREO UNA NUOVA COLONNA DOVE SALVO GLI ID UNICI CON MAP
    dataset['composite_stop_I'] = dataset['name'].map(name_to_composite_id_map)
    
    # CARICO E ANALIZZO I FILE CSV GIORNALIERI/SETTIMANALI:
    file_path_temporal = os.path.join(current_city_path, f"network_temporal_{periodo}.csv")
    dataset_temp = pd.read_csv(file_path_temporal, sep=';')
    
    # STESSO PROBLEMA SU QUESTI DATASET. HO BISOGNO ID UNICI PERCHE PIU ID STOP SONO ASSOCIATI
    # ALLA STESSA FERMATA/DESTINAZIONE. 
    # QUI DEVO SVOLGERE UN PASSAGGIO INTERMEDIO PERCHE COLONNA NAME NON è NEL DATASET CORRENTE:
    # è per questo che ho costruito la variabile dizionario "id_to_name_map"
    
    dataset_temp['from_stop_name'] = dataset_temp['from_stop_I'].map(id_to_name_map) 
    #aggiunge la colonna con i nomi delle fermate di partenza, utilizzando il diz come mappatura
    dataset_temp['composite_from_stop_I'] = dataset_temp['from_stop_name'].map(name_to_composite_id_map) 
    #aggiunge la colonna con gli stop id unici creati, utilizzando il diz come mappatura
    
    #SECONDO PROBLEMA: soprattutto in diversi file network_temporal_week, ci sono STOP ID che non
    #esistono nel file network_nodes, PER QUESTO NON SI RIESCE A IMPUTARE LO STOP ID AD UNA CITTA: 
    #PER QUESTO MOTIVO ASSUMONO VALORE "NAN" E VANNO ELIMINATI!
    
    # FILTRA il DataFrame togliendo le righe con NaN nella colonna chiave
    dataset_temp_clean = dataset_temp.dropna(subset=['composite_from_stop_I'])

    # Ora usa il dataset pulito per i conteggi
    # CONTA LE OCCORRENZE DI OGNI STOP ID UNICO CREATO, QUINDI LE OCCORRENZE DELLE CITTA
    # .value_counts() è un comando molto ottimizzato per questo, conta le occorrenze di ogni elemento della colonna
    conteggio_partenze = dataset_temp_clean['composite_from_stop_I'].value_counts()
    #ordina i conteggi in modo decrescente per impostazione predefinita: perfetto

    #PRENDO I 10 STOP ID UNICI PIU FREQUENTI, CON LE OCCORRENZE PIU ALTE
    dieci_pos = conteggio_partenze.head(10) #oggetto: series Panda
    
    print("/n----")
    print("Le 10 località da cui partono più viaggi da", citta, "al" ,periodo, "sono:")
    for comp_id, cont in dieci_pos.items():
    #nelle series di panda, è possibile utilizzare items, restituisce coppie (indice, valore)
        location_name = composite_id_to_name_map.get(comp_id) #dal diz, dico di prendere dalla chiave=id unico, il valore=nome localita
        print("Località:", location_name, "con n partenze", cont)

# --- Misurazione del tempo di esecuzione ---
start_time = time.time() # Registra il tempo di inizio

# Itera attraverso ogni città ed elabora i dati giornalieri e settimanali:
for citta in listacitta:
    top_10_partenze(citta, path_cartella, "day")
    top_10_partenze(citta, path_cartella, "week")
    
end_time = time.time() # Registra il tempo di fine
execution_time = end_time - start_time # Calcola la differenza

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi" )

## COMMENTI E COMPLESSITA ##
# La lettura dei file con pd.read_csv ha una complessità proporzionale alla dimensione del file,
# quindi O(N) e O(M) rispettivamente, dove N è il numero di righe di network_nodes.csv e M è il numero
# di righe del file temporale.
#
# Le operazioni di mappatura e conteggio (.map(), .value_counts()) sono ottimizzate per operare
# sull'intero DataFrame senza loop espliciti. Hanno una complessità temporale di O(M) per il file temporale
# e O(N) per il file dei nodi.
#
# Complessità totale per una singola esecuzione:
# Per una singola chiamata di top_10_partenze, la complessità è dominata dalla lettura dei file
# e dalle operazioni sui DataFrame, che è essenzialmente lineare, ovvero O(N + M).
#
# Complessità totale dell'intero script:
# Dato che il ciclo for esterno esegue la funzione due volte per ciascuna delle 25 città,
# il numero totale di chiamate è 2 * 25 = 50.
# LA COMPLESSITA TOTALE DELL ALGORITMO è quindi 50 * O(N + M).

#TEMPO DI ESECUZIONE: 163.90835738182068 secondi
    
######################################################################################
####################################################################################

## QUESTION 2
## DOMANDA 3

##Considerando il grafo non orientato U(G), calcola la distribuzione di grado: quali sono le 10 localita 
#con il grado piu alto? In pratica, si vuole calcolare quali siano le 10 localita piu "connesse" di ogni citta

#Degree (non orientato): Per ogni nodo nel grafo non orientato, conta il numero di archi a esso collegati.

## DEVO DARE DUE RISPOSTE: UNA GIORNALIERA, UNA SETTIMANALE

##USO NODES.CSV PER DEFINIRE I NODI DEL GRAFO (STOP ID)
## USO DAY.CSV E WEEK.CSV PER DEFINIRE GLI ARCHI DEL GRAFO (FROM STOP, TO STOP)

import pandas as pd
import networkx as nx
import os
import time #serve per il tempo di esecuzione

listacitta = ["adelaide", "belfast", "berlin", "bordeaux", "brisbane", "canberra", "detroit", "dublin", "grenoble", "helsinki", "kuopio", "lisbon", "luxembourg", "melbourne", "nantes", "palermo", "paris", "prague", "rennes", "rome", "sydney", "toulouse", "turku", "venice", "winnipeg"]

# Base path dove sono salvati i file csv delle citta
path_cartella = "C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject"

def top_10_gradi(citta, base_path, periodo):
    
    current_city_path = os.path.join(base_path, citta)
    file_path_nodes = os.path.join(current_city_path, "network_nodes.csv")
    dataset = pd.read_csv(file_path_nodes, sep=';')

    # CREO UN DIZIONARIO CHE MAPPA GLI STOP ID ORIGINALI AI NOMI: chiave=stop id, valore=nomi localita
    id_to_name_map = pd.Series(dataset['name'].values, index=dataset['stop_I']).to_dict()

    # CREO UN SECONDO DIZIONARIO CHE ASSOCIA A OGNI ID UNICO UNA CITTA/DESTINAZIONE:
    unique_names = dataset['name'].unique() # Trova i nomi unici delle località (eliminando i duplicati)
    name_to_composite_id_map = {name: idx for idx, name in enumerate(unique_names)} #creo dizionario
    #che associa ai nomi gli indici compositi: chiave=nomi fermate; valore=stop id unico
    composite_id_to_name_map = {idx: name for name, idx in name_to_composite_id_map.items()} #e viceversa
    #chiave= stop id unico; valore=nomi fermate

    # CREO UNA NUOVA COLONNA DOVE SALVO GLI INDICI COMPOSITI CON MAP
    dataset['composite_stop_I'] = dataset['name'].map(name_to_composite_id_map)
    
    #CREO UN NUOVO GRAFO VUOTO NON ORIENTATO
    G = nx.Graph() #creo grafo vuoto: si tratta gia cosi di un grafo non orientato (altrimenti nx.DiGraph)
    
    #SALVO GLI STOP ID UNICI CREATI COME UNA LISTA IN MODO DA USARE IL COMANDO SUCCESSIVO:
    stop_ids = list(dataset['composite_stop_I']) #lista dei valori dei nodi (STOP ID COMPOSITI) della citta
    G.add_nodes_from(stop_ids) #-Aggiungere una lista di nodi
    
    # CARICO E ANALIZZO I FILE CSV GIORNALIERI/SETTIMANALI:
    file_path_temporal = os.path.join(current_city_path, f"network_temporal_{periodo}.csv")
    dataset_temp = pd.read_csv(file_path_temporal, sep=';')
    
    #MAPPO INDICI COMPOSITI PER FROM STOP I:
    dataset_temp['from_stop_name'] = dataset_temp['from_stop_I'].map(id_to_name_map) #aggiunge la colonna con i nomi delle partenze
    dataset_temp['composite_from_stop_I'] = dataset_temp['from_stop_name'].map(name_to_composite_id_map) 
    #aggiunge la colonna con gli stop id unici creati
    
    #MAPPO INDICI COMPOSITI PER TO STOP I:
    dataset_temp['to_stop_name'] = dataset_temp['to_stop_I'].map(id_to_name_map) #aggiunge la colonna con i nomi degli arrivi
    dataset_temp['composite_to_stop_I'] = dataset_temp['to_stop_name'].map(name_to_composite_id_map) 
    #aggiunge la colonna con gli stop id unici creati
    
    # FILTRA le righe dove ENTRAMBI gli ID sono validi (non NaN)
    valid_edges_mask = dataset_temp['composite_from_stop_I'].notna() & dataset_temp['composite_to_stop_I'].notna()
    dataset_temp_clean = dataset_temp[valid_edges_mask]

    # Ora usa il dataset pulito per creare la lista di archi
    edges_to_add = list(zip(dataset_temp_clean['composite_from_stop_I'], dataset_temp_clean['composite_to_stop_I']))
    #prende le due colonne del dataset e le zippa insieme, cioè crea una tupla per ogni riga del dataset
    #di due valori: (from stop,to stop). CIASCUNA TUPLA è UN ARCO. LO TRASFORMO IN UNA LISTA DI TUPLE
    #PER PASSARLO A G ADD EDGE
    
    # SOLUZIONE EFFICIENTE E PRECISA: ELIMINO ARCHI DUPLICATI E SELF-LOOP(STESSA PARTENZA-ARRIVO)
    # Creo un set di tuple per rimuovere i duplicati [I set non permettono duplicati].
    #Rimuovere gli archi duplicati (es:100 autobus che vanno dalla fermata A alla fermata B, algoritmo li aggiunge tutti. Siccome
    # NetworkX memorizza un arco tra due nodi una sola volta, indipendentemente da quante volte lo aggiungi, tenere gli archi 
    #duplicati  non distorce il risultato, ma eliminarli permette di risparmiare tempo e memoria. 
    #SELF-LOOPS: Alcune righe nei dati potrebbero avere from_stop_I == to_stop_I (un autobus che "parte" e "arriva"
    #alla stessa fermata, magari per un errore nei dati o per una peculiarità del percorso). Nel contesto di questa 
    #analisi di rete, questi self-loops non sono informativi e andrebbero rimossi.
    
    # Filtra anche gli archi dove from != to per rimuovere self-loops.
    edges_set = set()
    for edge in edges_to_add:
        if edge[0] != edge[1]:  # Esclude i self-loops
            # Aggiunge l'arco in forma normalizzata (tupla ordinata) per il grafo non orientato.
            # Questo assicura che (u, v) e (v, u) siano considerati lo stesso arco.
            sorted_edge = tuple(sorted(edge))
            edges_set.add(sorted_edge)

    # Aggiungi tutti gli archi in blocco, è il metodo piu efficiente 
    G.add_edges_from(edges_set)
    
    # ADESSO CALCOLO MANUALMENTE I GRADI DEI NODI:
    # Creiamo un dizionario per tenere traccia del grado di ogni nodo.
    # Inizializziamo tutti i gradi a zero. Usiamo gli ID compositi unici come chiavi.
    grado_nodo_dict = {node_id: 0 for node_id in stop_ids}

    # Per ogni arco nel nostro set (u, v), incrementiamo il grado di entrambi i nodi.
    # Ricorda: edges_set contiene archi normalizzati (tuple ordinate) senza duplicati.
    for edge in edges_set: #itero nel set di archi non orientati e senza duplicati
    
        grado_nodo_dict[edge[0]] += 1  # edge[0] è il primo elemento (u) della tupla(arco)
        grado_nodo_dict[edge[1]] += 1  # edge[1] è il secondo elemento (v) della tupla(arco)
        #Questo perché in un grafo non orientato, un arco contribuisce al grado di entrambi i nodi che collega.

    # Cosi {id_nodo: grado}
    #PER OTTENERE UNA CLASSIFICA DELLE LOCALITA PIU CONNESSE, TRASFORMO QUESTO OGGETTO IN UNA PANDAS SERIES,
    #CHE è FACILMENTE MANIPOLABILE:
    gradi_nodi_series = pd.Series(grado_nodo_dict) #chiave=nodo=stop id unico, valore=grado del nodo

    # Ordina la Series per i suoi valori (gradi) in ordine decrescente
    gradi_ordinati_decrescente = gradi_nodi_series.sort_values(ascending=False)

    # OTTENGO I NOMI DELLE 10 LOCALITA PIU CONNESSE:
    #Rinomina gli indici con i nomi delle località e prende i primi 10
    gradi_con_nomi_nodi = gradi_ordinati_decrescente.rename(index= composite_id_to_name_map).head(10)
    #uso il dizionario inverso per sostituire gli ID numerici con i nomi delle località. (rename)
    #seleziona le prime 10 righe, ovvero le 10 località con il grado più alto.(head)
    
    print("/n---")
    print("Le 10 località con il grado piu alto di", citta, "al", periodo, "sono:")
    for nome_nodo, gradi in gradi_con_nomi_nodi.items():
        print("località:", nome_nodo, ", con grado del nodo", gradi)             

# --- Misurazione del tempo di esecuzione ---
start_time = time.time() # Registra il tempo di inizio

for citta in listacitta:
    top_10_gradi(citta, path_cartella, "day")
    top_10_gradi(citta, path_cartella, "week")
    
end_time = time.time() # Registra il tempo di fine
execution_time = end_time - start_time # Calcola la differenza

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi" )

#tempo di esecuzione: 327.4330759048462 secondi, circa 5 minuti

#In sintesi, il codice crea un grafo per ogni città, dove le località sono i nodi e i viaggi sono gli archi.
#Quindi calcola il grado di ogni nodo per misurarne la connettività e infine estrae e stampa le 10 località 
#con il grado più elevato.
    
##COMMENTI E COMPLESSITA:
#inzialmente avevo implementato un ciclo for per aggiungere gli archi ma è risultato inefficiente
#per questo ho creato prima una lista e poi aggiunto la lista di archi al grafo

## MIGLIORATO MOLTO IL TEMPO DI ESECUZIONE:
#tempo di esecuzione con for: 646 secondi, poco piu di 10 minuti ##
#tempo di esecuzione senza for: 352.17932415008545, poco di piu di 5 minuti ##
#tempo di esecuzione levando archi duplicati e self loops: 327.4330759048462 secondi

## La lettura dei CSV ha una complessità lineare rispetto alla dimensione dei file.
# Le operazioni di pandas e networkx (.map(), G.add_nodes_from(), G.add_edges_from()), 
# sono estremamente ottimizzate e agiscono in tempo quasi-lineare rispetto al numero di nodi e archi.
# L'unica operazione con una complessità superiore è l'ordinamento (.sort_values()), che ha una complessità di
# O(V_unici log V_unici), dove V_unici è il numero di località uniche.
# Tuttavia, poiché V_unici è molto più piccolo del numero di archi, il costo complessivo è dominato dalla 
#costruzione del grafo.

#complessita totale: 
# T_totale = Ncitta * 2 * O(V_nodes + E_temporal + V_unique_places * log(V_unique_places))
#
# Dove:
# - Ncitta: Numero di città nella lista 'listacitta'.
# - 2: Rappresenta le due analisi per periodo ("day" e "week") per ogni città.
# - V_nodes: Numero di nodi nel grafo (corrisponde agli stop unici per una città).
# - E_temporal: Numero di archi nel grafo (corrisponde alle connessioni temporali 'from_stop_I' a 'to_stop_I').
# - V_unique_places: Numero di località uniche identificate dai nomi (per la mappatura degli ID compositi).
# - log(V_unique_places): Deriva dall'ordinamento dei gradi per ottenere la top 10.

####################################################################################
####################################################################################

##QUESTION 3
##DOMANDA A

# "Considerando U(G) e restringendo alla sua componente connessa più grande V', calcola ESATTAMENTE il diametro 
# del grafo indotto dai vertici in V"

#grafo non orientato: ce lho gia

#componente connessa piu grande: in un grafo non orientato, una componente connessa 
#è un sottografo in cui esiste un percorso tra ogni coppia di nodi al suo interno. Un grafo 
#può avere una o più componenti connesse. Tra tutte le componenti connesse di U(G), devi identificare 
#quella che contiene il maggior numero di nodi.

#Diametro del Grafo: Il diametro di un grafo connesso è la massima distanza più breve tra 
#qualsiasi coppia di nodi nel grafo. 

import pandas as pd
import networkx as nx
import os
import time

listacitta = ["adelaide", "belfast", "berlin", "bordeaux", "brisbane", "canberra", "detroit", "dublin", "grenoble", "helsinki", "kuopio", "lisbon", "luxembourg", "melbourne", "nantes", "palermo", "paris", "prague", "rennes", "rome", "sydney", "toulouse", "turku", "venice", "winnipeg"]

path_cartella = "C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject"

def calcola_diametro_componente_maggiore(citta, base_path, periodo):
    
    current_city_path = os.path.join(base_path, citta)
    file_path_nodes = os.path.join(current_city_path, "network_nodes.csv")
    dataset = pd.read_csv(file_path_nodes, sep=';')

    # CREO UN DIZIONARIO CHE MAPPA GLI STOP ID ORIGINALI AI NOMI: stop id=chiave, nomi=valore
    id_to_name_map = pd.Series(dataset['name'].values, index=dataset['stop_I']).to_dict()
    
    # CREO UN SECONDO DIZIONARIO CHE ASSOCIA A OGNI ID UNICO UNA CITTA/DESTINAZIONE:
    unique_names = dataset['name'].unique() # Trova i nomi unici delle località (eliminando i duplicati)
    name_to_composite_id_map = {name: idx for idx, name in enumerate(unique_names)} #creo dizionario
    #che associa ai nomi gli indici compositi: chiave=nomi fermate; valore=stop id unico
    composite_id_to_name_map = {idx: name for name, idx in name_to_composite_id_map.items()} #e viceversa
    #chiave= stop id unico; valore=nomi fermate
    
    # CREO UNA NUOVA COLONNA DOVE SALVO GLI INDICI COMPOSITI CON MAP
    dataset['composite_stop_I'] = dataset['name'].map(name_to_composite_id_map)

    # Questo G è già U(G) perché nx.Graph() è non orientato
    G = nx.Graph()
    stop_ids = list(dataset['composite_stop_I'])
    G.add_nodes_from(stop_ids) #aggiunta lista di nodi

    # CARICO E ANALIZZO I FILE CSV GIORNALIERI/SETTIMANALI:
    file_path_temporal = os.path.join(current_city_path, f"network_temporal_{periodo}.csv")
    dataset_temp = pd.read_csv(file_path_temporal, sep=';')
    
    #mappo indici compositi di from stop i
    dataset_temp['from_stop_name'] = dataset_temp['from_stop_I'].map(id_to_name_map)
    dataset_temp['composite_from_stop_I'] = dataset_temp['from_stop_name'].map(name_to_composite_id_map)
    
    #mappo indici compositi to stop i
    dataset_temp['to_stop_name'] = dataset_temp['to_stop_I'].map(id_to_name_map)
    dataset_temp['composite_to_stop_I'] = dataset_temp['to_stop_name'].map(name_to_composite_id_map)
    
    # FILTRA le righe dove ENTRAMBI gli ID sono validi (non NaN)
    valid_edges_mask = dataset_temp['composite_from_stop_I'].notna() & dataset_temp['composite_to_stop_I'].notna()
    dataset_temp_clean = dataset_temp[valid_edges_mask]

    # Ora usa il dataset pulito per creare la lista di archi
    edges_to_add = list(zip(dataset_temp_clean['composite_from_stop_I'], dataset_temp_clean['composite_to_stop_I']))
    #prende le due colonne del dataset e le zippa insieme, cioè crea una tupla per ogni riga del dataset
    #di due valori: (from stop,to stop). CIASCUNA TUPLA è UN ARCO. LO TRASFORMO IN UNA LISTA DI TUPLE
    #PER PASSARLO A G ADD EDGE
    
    # SOLUZIONE EFFICIENTE E PRECISA: ELIMINO ARCHI DUPLICATI E SELF-LOOP(STESSA PARTENZA-ARRIVO)
    # Creo un set di tuple per rimuovere i duplicati [I set non permettono duplicati].
    
    # Filtro gli archi dove from != to per rimuovere self-loops.
    edges_set = set()
    for edge in edges_to_add:
        if edge[0] != edge[1]:  # Esclude i self-loops
            # Aggiunge l'arco in forma normalizzata (tupla ordinata) per il grafo non orientato.
            # Questo assicura che (u, v) e (v, u) siano considerati lo stesso arco.
            sorted_edge = tuple(sorted(edge))
            edges_set.add(sorted_edge)
    
    #aggiungo gli archi validi al grafo
    G.add_edges_from(edges_set)
    
    ## PASSAGGI PER CALCOLARE ESATTAMENTE IL DIAMETRO DEL GRAFO ##
    #1. calcolo tutte componenti connesse del grafo:
    components = list(nx.connected_components(G))
    #nx.connected_components(G) restituisce un iteratore di insiemi (set), dove ogni insieme contiene i nodi di una componente connessa.

    # 2. Identifica la componente connessa più grande: identifica la porzione più estesa della rete di trasporto pubblico
    largest_component = max(components, key=len)
    #max() con key=len ti permette di trovare l'insieme (la componente) con la dimensione massima.

    # 3. Crea il sottografo indotto della componente connessa piu grande
    G_largest_cc = G.subgraph(largest_component)
    #questo nuovo grafo (G_largest_cc) contiene solo i nodi e gli archi che appartengono alla componente connessa più grande.
    #Questo passaggio è necessario per calcolare il diametro esclusivamente su quella porzione del grafo.
    
    # 4. Calcolare il Diametro di G_largest_cc:
    diametro= nx.diameter(G_largest_cc)
    #Attenzione: nx.diameter() richiede che il grafo sia connesso. Poiché G_largest_cc è per definizione
    # la componente connessa più grande, sarà connesso e il comando funzionerà correttamente, senza cadere in errrori
    
    print("/n---")
    print("Diametro della componente connessa più grande del grafo della citta",citta, "al",periodo,"è:" ,diametro)
    print("Numero di nodi nella componente connessa più grande:", len(largest_component))

# Loop principale per l'esecuzione
start_time = time.time()

for citta in listacitta:
    calcola_diametro_componente_maggiore(citta, path_cartella, "day")
    #calcola_diametro_componente_maggiore(citta, path_cartella, "week")

end_time = time.time()
execution_time = end_time - start_time

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi")


################################ ATTENZIONE  ###################################
# IL CICLO FOR GIRA ALL INFINITO: SICCHE HO APPROFONDITO LA SITUAZIONE:

### applicato algoritmo per turku (citta piccola) e cosi va velocemente [19 secondi]  ##
start_time = time.time()

calcola_diametro_componente_maggiore("turku", path_cartella, "day")
calcola_diametro_componente_maggiore("turku", path_cartella, "week")

end_time = time.time()
execution_time = end_time - start_time

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi")

### per adelaide, la prima citta della lista, ci mette molto: circa 10 minuti solo per questa citta ##
start_time = time.time()

calcola_diametro_componente_maggiore("adelaide", path_cartella, "day")
calcola_diametro_componente_maggiore("adelaide", path_cartella, "week")

end_time = time.time()
execution_time = end_time - start_time

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi")

#CONCLUSIONE:SICCOME COMPLESSITA DELL ALGORITMO è BUONA
#OPPURE IL GRAFO è MOLTO CONNESSO E CADE IN TEMPO QUADRATICO ##

# RICORDA: AL MASSIMO IL DIAMETRO PUO DIMINUIRE O RIMANERE INVARIATO TRA DAY E WEEK, NON
# POTRA MAI AUMENTARE, PERCHè IL DIAMETRO SI TRATTA DEL PERCORSO PIU LUNGO TRA I PIU BREVI #
##################################################################################

## COMMENTI E COMPLESSITA:
# La lettura dei CSV e la costruzione del grafo sono fasi caratterizzate da operazioni 
# che hanno una complessità quasi-lineare, con un costo proporzionale alla dimensione dei dati.
#
# nx.connected_components(G) utilizza un algoritmo come la BFS (Breadth-First Search) o la DFS (Depth-First Search), 
# con una complessità di O(V + E), dove V è il numero di nodi ed E è il numero di archi del grafo intero.
# Questa fase è molto efficiente.
#
# Calcolo del diametro:
# Questa è l'operazione più costosa. nx.diameter() calcola la distanza più breve (tramite BFS) 
# da ogni nodo a tutti gli altri nodi all'interno della componente connessa più grande.
# La complessità è quindi O(V_cc * (V_cc + E_cc)), dove V_cc ed E_cc sono i nodi e gli archi 
# della componente connessa più grande.
#
# Questo può diventare molto lento per grafi densi o con un grande numero di nodi.
# Il tempo di esecuzione di questa operazione cresce quadraticamente all'aumentare della grandezza del grafo.

## una soluzione potrebbe essere fare un calcolo approssimato del diametro della componente connessa piu grande ##

################################################################################
################################################################################

## DOMANDA 4: UGUALE PER TUTTI ##

##RICHIESTA 1: TRACCIA IL NUMERO DI ARCHI NEL TEMPO, POSSIBILMENTE USANDO MATPLOTLIB

#IN QUESTO CASO, NON MI SERVE COSTRUIRE IL GRAFO!!!
#MI BASTA ANALIZZARE IL DATASET

import pandas as pd
import os
import time
import matplotlib.pyplot as plt #per la creazione di grafici e visualizzazioni

listacitta = ["adelaide", "belfast", "berlin", "bordeaux", "brisbane", "canberra", "detroit", "dublin", "grenoble", "helsinki", "kuopio", "lisbon", "luxembourg", "melbourne", "nantes", "palermo", "paris", "prague", "rennes", "rome", "sydney", "toulouse", "turku", "venice", "winnipeg"]

path_cartella = "C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject"

def domanda1(citta, base_path, periodo):
    
    current_city_path = os.path.join(base_path, citta)
    file_path_temporal = os.path.join(current_city_path, f"network_temporal_{periodo}.csv")
    dataset_temp = pd.read_csv(file_path_temporal, sep=';')
    
    ## ARCHI NEL TEMPO PER DATASET GIORNALIERO E SETTIMANALE ##
    
    #trasforma la colonna in un oggetto di pandas: ho convertito le info sul tempo in un formato leggibile
    dataset_temp['dep_time_datetime'] = pd.to_datetime(dataset_temp['dep_time_ut'], unit='s')
    #crea una nuova colonna con contiene l ora di partenza in un formato leggibile
    
    #RAGGRUPPO IL DATASET IN BASE AGLI ORARI DI PARTENZA:
    archi_orari = dataset_temp.set_index('dep_time_datetime').resample('h').size() 
    # questo comando raggruppa i dati su base oraria e conta il numero di eventi in ogni intervallo.:
    #.set_index: usa la nuova colonna come indice
    #.resample raggruppa i dati in base oraria (H)
    #.size conta le occorrenze , ovvero il numero di righe di ogni intervallo orario
    #quindi conta il numero di occorrenze per ogni intervallo orario, basandosi sui valori della colonna 'dep_time_datetime'.
    
    #applico matplotlib per creare grafici:
    plt.figure(figsize=(12, 6))
    archi_orari.plot()
    plt.title(f'Numero di connessioni orarie a {citta.capitalize()} ({periodo.capitalize()})')
    plt.xlabel('Ora del Giorno')
    plt.ylabel('Numero di Connessioni')
    plt.grid(True)
    plt.tight_layout()
    plt.show()
    #plt.savefig(f"{citta}_{periodo}_connections_over_time.png") #evito di salvare i grafici perche aumenta tempo computazionale
    plt.close() # Chiudi la figura per non occupare memoria

# Loop principale per l'esecuzione
start_time = time.time()

for citta in listacitta:
    domanda1(citta, path_cartella, "day")
    domanda1(citta, path_cartella, "week")

end_time = time.time()
execution_time = end_time - start_time

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi")
    
#TEMPO DI ESECUZIONE:
#se uso plt.show: 237.18896079063416 secondi, 
#se uso plt.savefig: 416.08895611763 secondi, superiore
#meglio con plt.show

## COMMENTI E COMPLESSITA ##
# Per ogni città e periodo, la complessità è dominata dalle operazioni di lettura dei file
# e dalle operazioni di pandas, che sono lineari rispetto al numero di righe (N) del dataset.
#
# Il costo totale è la somma dei costi lineari per ogni file processato,
# quindi ∑(i=1 to 50) O(N_i), dove N_i è il numero di righe del file i-esimo.

#complessita totale: numero di citta=costante=25 e due chiamate dell algoritmo
#dunque, complessita totale: 50*O(N+M), dove N=n righe dataset day, M=n righe dat week

####################################################################################

## RICHIESTA 2: DOMANDA 4

#"Quante diverse località ci sono nel file network_temporal_week.csv e 
#in network_temporal_day.csv?" (perche non c'è la colonna name)

#nota: mi chiede il numero, quindi posso lasciare indici,
#utilizzo id unici/compositi in modo da essere sicuro di prendere le localita solo una volta 

import pandas as pd  
import os
import time

listacitta = ["adelaide", "belfast", "berlin", "bordeaux", "brisbane", "canberra", "detroit", "dublin", "grenoble", "helsinki", "kuopio", "lisbon", "luxembourg", "melbourne", "nantes", "palermo", "paris", "prague", "rennes", "rome", "sydney", "toulouse", "turku", "venice", "winnipeg"]

path_cartella = "C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject"

def domanda2(citta, base_path, periodo):
    
    current_city_path = os.path.join(base_path, citta)
    file_path_nodes = os.path.join(current_city_path, "network_nodes.csv")
    dataset = pd.read_csv(file_path_nodes, sep=';')

    # CREO UN DIZIONARIO CHE MAPPA GLI STOP ID ORIGINALI AI NOMI: chiave=stop id, valore=nomi localita
    id_to_name_map = pd.Series(dataset['name'].values, index=dataset['stop_I']).to_dict()

    # CREO UN SECONDO DIZIONARIO CHE ASSOCIA A OGNI ID UNICO UNA CITTA/DESTINAZIONE:
    unique_names = dataset['name'].unique() # Trova i nomi unici delle località (eliminando i duplicati)
    name_to_composite_id_map = {name: idx for idx, name in enumerate(unique_names)} #creo dizionario
    #che associa ai nomi gli indici compositi: chiave=nomi fermate; valore=stop id unico
    composite_id_to_name_map = {idx: name for name, idx in name_to_composite_id_map.items()} #e viceversa
    #chiave= stop id unico; valore=nomi fermate
    
    # CARICO E ANALIZZO I FILE CSV GIORNALIERI/SETTIMANALI:
    file_path_temporal = os.path.join(current_city_path, f"network_temporal_{periodo}.csv")
    dataset_temp = pd.read_csv(file_path_temporal, sep=';')
    
    #MAPPO INDICI COMPOSITI PER FROM STOP I:
    dataset_temp['from_stop_name'] = dataset_temp['from_stop_I'].map(id_to_name_map) #aggiunge la colonna con i nomi delle partenze
    dataset_temp['composite_from_stop_I'] = dataset_temp['from_stop_name'].map(name_to_composite_id_map) #aggiunge la colonna con gli stop id unici creati
    
    #MAPPO INDICI COMPOSITI PER TO STOP I:
    dataset_temp['to_stop_name'] = dataset_temp['to_stop_I'].map(id_to_name_map) #aggiunge la colonna con i nomi degli arrivi
    dataset_temp['composite_to_stop_I'] = dataset_temp['to_stop_name'].map(name_to_composite_id_map) #aggiunge la colonna con gli stop id unici creati
    #RISOLTO PROBLEMA ID MULTIPLI: ADESSO OGNI LOCALITA è ASSOCIATA A UN DIVERSO ID
    
    # Seleziona solo le righe dove gli ID compositi sono validi (non NaN)
    valid_from = dataset_temp['composite_from_stop_I'].notna()
    valid_to = dataset_temp['composite_to_stop_I'].notna()
    
    # Prendi gli ID validi da entrambe le colonne
    from_ids_valid = dataset_temp.loc[valid_from, 'composite_from_stop_I']
    to_ids_valid = dataset_temp.loc[valid_to, 'composite_to_stop_I']

    # Unisce gli ID VALIDI di partenza e arrivo e conta i valori unici. li salvo in una serie pandas
    all_temporal_stop_ids = pd.concat([from_ids_valid, to_ids_valid]).unique()
    
    #il risultato è una array di id unici, dove ognuno rappresenta una localita, senza duplicati
    loc_div=len(all_temporal_stop_ids) #num di location diverse per citta per periodo
    
    print("/n---")
    print("il numero di localita differenti presenti a",citta, "al",periodo,"è:" ,loc_div)
    
    return loc_div #la funzione restituisce il numero calcolato

# Loop principale per l'esecuzione
start_time = time.time()

#numero totale aggregato delle localita
somma_day=0
somma_week=0

for citta in listacitta:
    tot_loc_citta_day=domanda2(citta, path_cartella, "day")
    somma_day +=tot_loc_citta_day
    tot_loc_citta_week=domanda2(citta, path_cartella, "week")
    somma_week += tot_loc_citta_week
print("le localita diverse totali a livello aggregato al giorno sono",somma_day)
print("le localita diverse totali a livello aggregato alla settimana sono",somma_week)

end_time = time.time()
execution_time = end_time - start_time

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi")
        
#tempo di esecuzione: 156.06499218940735 secondi, poco

#commenti e complessita:
    
#Creare dizionari, cercare valori unici (unique()) e mappare valori (.map()) su un DataFrame di Pandas 
#ha una complessità temporale quasi lineare. Poiché ogni stop_I viene processato una volta per creare i 
#dizionari, la complessità è dominata da O(N), dove N è il numero di nodi. Anche se ci sono più passaggi, 
#la complessità rimane lineare.
#
#Il caricamento del file temporale (pd.read_csv) richiede un tempo lineare rispetto al numero di righe M,
# quindi ha una complessità di O(M).
#La mappatura degli ID avviene anch'essa in tempo lineare. Per ogni riga del DataFrame dataset_temp
# (che sono M), viene eseguita una ricerca nel dizionario, che in media ha una complessità O(1). Quindi, 
#l'operazione di mappatura è O(M).
#
# Le operazioni .concat() e .unique() sono estremamente veloci e hanno una complessità lineare
# rispetto alla dimensione del dataset temporale. O(M)
#len() su un array ha una complessità di O(1).
#
# L'algoritmo ha una complessità temporale di O(N+M), considerando la funzione implementata:
#se considero anche il for ho una complessita di 50*O(N+M), dove N=n righe dataset day, M=n righe dat week,
#dove questi due parametri variano ad ogni chiamata

#####################################################################################

## RICHIESTA 3 DOMANDA 4

# "Quante connessioni dirette ci sono nei due file?"

#siccome i due file (day,week) sono file che esprimono i trasporti da un punto all altro
#queste sono connessioni dirette di un grafo: quindi le righe del
#dataset sono le connessioni dirette!!! (archi orientati non unici del grafo)

#PROBLEMA: io voglio contare solo le connessioni dirette uniche!!
#quindi devo verificare se ci sono duplicati oppure no

## Interpretazione: Numero di archi orientati unici nel grafo della rete di trasporti.

import pandas as pd
import os
import time

listacitta = ["adelaide", "belfast", "berlin", "bordeaux", "brisbane", "canberra", "detroit", "dublin", "grenoble", "helsinki", "kuopio", "lisbon", "luxembourg", "melbourne", "nantes", "palermo", "paris", "prague", "rennes", "rome", "sydney", "toulouse", "turku", "venice", "winnipeg"]

path_cartella = "C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject"

def domanda3(citta, base_path, periodo):
    
    current_city_path = os.path.join(base_path, citta)
    file_path_nodes = os.path.join(current_city_path, "network_nodes.csv")
    dataset = pd.read_csv(file_path_nodes, sep=';')
    
    # Crea dizionari per la mappatura agli ID compositi
    id_to_name_map = pd.Series(dataset['name'].values, index=dataset['stop_I']).to_dict()
    unique_names = dataset['name'].unique()
    name_to_composite_id_map = {name: idx for idx, name in enumerate(unique_names)}
    
    # 2. CARICA IL FILE TEMPORALE
    file_path_temporal = os.path.join(current_city_path, f"network_temporal_{periodo}.csv")
    dataset_temp = pd.read_csv(file_path_temporal, sep=';')
    
    # 3. MAPPA GLI ID ORIGINALI AGLI ID COMPOSITI UNICI
    # Per from_stop_I
    dataset_temp['from_stop_name'] = dataset_temp['from_stop_I'].map(id_to_name_map)
    dataset_temp['composite_from_stop_I'] = dataset_temp['from_stop_name'].map(name_to_composite_id_map)
    # Per to_stop_I
    dataset_temp['to_stop_name'] = dataset_temp['to_stop_I'].map(id_to_name_map)
    dataset_temp['composite_to_stop_I'] = dataset_temp['to_stop_name'].map(name_to_composite_id_map)
    
    # 4. FILTRA RIGHE CON ID VALIDI (rimuovi NaN)
    valid_mask = dataset_temp['composite_from_stop_I'].notna() & dataset_temp['composite_to_stop_I'].notna()
    dataset_temp_clean = dataset_temp[valid_mask]
    
    # 5. CREA LA LISTA DI ARCHI ORIENTATI (from, to)
    edges_oriented = list(zip(dataset_temp_clean['composite_from_stop_I'], dataset_temp_clean['composite_to_stop_I']))
    
    # 6. CALCOLA ARCHI ORIENTATI UNICI
    # Usa un set per rimuovere duplicati. Nota: (A, B) e (B, A) sono considerati ARCHI DIVERSI.
    unique_oriented_edges = set(edges_oriented)
    
    # 7. IL NUMERO DI ARCHI ORIENTATI UNICI È LA RISPOSTA
    num_direct_connections = len(unique_oriented_edges)
    
    print("/n---")
    print("Numero di archi orientati unici (connessioni dirette) a",citta, "al",periodo,"è:" ,num_direct_connections)
    
    return num_direct_connections

# Esecuzione principale
start_time = time.time()

somma_day = 0
somma_week = 0

for citta in listacitta:
    conn_day = domanda3(citta, path_cartella, "day")
    somma_day += conn_day
    conn_week = domanda3(citta, path_cartella, "week")
    somma_week += conn_week

print("\n--- TOTALI ---")
print("Totale aggregato di connessioni dirette (archi orientati unici) - Giorno:", somma_day)
print("Totale aggregato di connessioni dirette (archi orientati unici) - Settimana:", somma_week)

end_time = time.time()
execution_time = end_time - start_time

print("\n---")
print("Tempo totale di esecuzione dello script:", execution_time, "secondi")

##tempo di esecuzione: 217.32507467269897 secondi

###commmenti e complessita ### 

# La complessità dell'algoritmo è lineare rispetto alla dimensione dell'input, ovvero O(N + M),
# dove N è il numero di righe nel file dei nodi e M è il numero di righe nel file temporale.
#
# Dettaglio delle operazioni principali:
# - Lettura dei file CSV: O(N) per i nodi, O(M) per i dati temporali.
# - Mappature, filtri e zip: O(M).
# - Creazione di un set per rimuovere duplicati: O(M) in media.
# - Operazioni finali come len() sono trascurabili (O(1)).
#
# Lo script processa ogni città due volte (modalità "day" e "week"),
# quindi la complessità totale è:
# O(2 * Σ (N_i + M_i_day + M_i_week)) per i = 1 a 25 città,
# che rimane lineare rispetto alla dimensione complessiva degli input.

#################################################################################

## RICHIESTA 4 DOMANDA 4: TEORICA 

"""
Quanto tempo impiega il tuo programma per rispondere alle domande per ciascuno dei due file? 
Come si comporta rispetto al numero di località e al numero di connessioni dirette?

PRIMA DOMANDA: non impiega molto, per il calcolo delle localita diverse impiega 136 secondi,
per il calcolo delle connessioni dirette impiega 217 secondi. Probabilmente impiegherà piu per
calcolare sui file_week.csv perchè sono piu grossi (hanno piu righe) rispetto ai file_day.csv

SECONDA DOMANDA: All'aumentare del numero di connessioni dirette e/o del numero di località uniche, 
il tempo di esecuzione aumenterà. 
file piu grande->citta piu grande->numero localita/connessioni dirette + alto->tempo di esecuzione e memoria usata + alto
Il programma si comporta in modo lineare rispetto alla dimensione dei dati.
Inoltre, confrontando l' output dei due algoritmi, si può notare che il numero di connessioni è maggiore del
numero di località diverse: questo è un indicatore della densità e della connettività di una rete di trasporto
pubblico come questa.
"""

################################################################################################################
################################################################################################################

############ PROVA ESISTENZA STOP ID DIVERSI CHE SI RIFERISCONO ALLA STESSA LOCALITA ################

#guardato file nodes di Venezia, guardando le ultime righe si notano diversi casi di questo tipo

####################### PROVA ESISTENZA NAN IN DETERMINATI FILE #####################################

## USO LIBRERIA PANDAS ##

import pandas as pd
import os  #libreria per interagire piu velocemente con il sistema operativo
import time #serve per il tempo di esecuzione

listacitta = ["adelaide", "belfast", "berlin", "bordeaux", "brisbane", "canberra", "detroit", "dublin", "grenoble", "helsinki", "kuopio", "lisbon", "luxembourg", "melbourne", "nantes", "palermo", "paris", "prague", "rennes", "rome", "sydney", "toulouse", "turku", "venice", "winnipeg"]

# Base path dove sono salvati i file csv delle citta
path_cartella = "C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject"

#CONTROLLO NAN: non ce stop 91 in belfast network.nodes, quindi non so a che localita si riferisca, va tolto!

def provanan(citta, base_path, periodo):

    current_city_path = os.path.join(base_path, citta) #percorso da basepath alla cartella della citta
    file_path_nodes = os.path.join(current_city_path, "network_nodes.csv") #percorso da cartella citta a file dei nodi
    dataset = pd.read_csv(file_path_nodes, sep=';')
    
    #PROBLEMA GENERALE DEL DATASET: PIU STOP ID SONO ASSOCIATI ALLA STESSA FERMATA/DESTINAZIONE.
    #IL PROBLEMA è STATO RISOLTO COSTRUENDO DEGLI ID UNICI/COMPOSITI, UNO PER OGNI FERMATA.

    # CREO UN DIZIONARIO CHE MAPPA GLI STOP ID ORIGINALI AI NOMI DELLE CITTA: chiave=stop id; valore=citta
    id_to_name_map = pd.Series(dataset['name'].values, index=dataset['stop_I']).to_dict() #fondamentale nella fase successiva

    # CREO UN SECONDO DIZIONARIO CHE ASSOCIA A OGNI ID UNICO UNA CITTA/DESTINAZIONE:
    unique_names = dataset['name'].unique() # Trova i nomi unici delle località (eliminando i duplicati)
    name_to_composite_id_map = {name: idx for idx, name in enumerate(unique_names)} #creo dizionario
    #che associa ai nomi gli gli stop id unici: chiave=nomi fermate; valore=stop id unico
    composite_id_to_name_map = {idx: name for name, idx in name_to_composite_id_map.items()} #e viceversa
    #chiave= stop id unico; valore=nomi fermate

    # CREO UNA NUOVA COLONNA DOVE SALVO GLI ID UNICI CON MAP
    dataset['composite_stop_I'] = dataset['name'].map(name_to_composite_id_map)
    
    # CARICO E ANALIZZO I FILE CSV GIORNALIERI/SETTIMANALI:
    file_path_temporal = os.path.join(current_city_path, f"network_temporal_{periodo}.csv")
    dataset_temp = pd.read_csv(file_path_temporal, sep=';')
    
    # STESSO PROBLEMA SU QUESTI DATASET. HO BISOGNO ID UNICI PERCHE PIU ID STOP SONO ASSOCIATI
    # ALLA STESSA FERMATA/DESTINAZIONE. 
    # QUI DEVO SVOLGERE UN PASSAGGIO INTERMEDIO PERCHE COLONNA NAME NON è NEL DATASET CORRENTE:
    # è per questo che ho costruito la variabile dizionario "id_to_name_map"
    
    dataset_temp['from_stop_name'] = dataset_temp['from_stop_I'].map(id_to_name_map) 
    #aggiunge la colonna con i nomi delle fermate, utilizzando il diz come mappatura
    #QUELLO CHE ACCADE è: FROM STOP I =STOP I ORIGINALE? SI , GLI DO IL NOME OPPURE NAN
    

    # 1. Crea una maschera booleana che identifica le righe dove la mappatura ha fallito
    righe_con_nan = dataset_temp['from_stop_name'].isna()

    # 2. Usa la maschera per filtrare il DataFrame e mostrare SOLO le righe problematiche
    righe_problematiche = dataset_temp[righe_con_nan]

    # 3. Stampa il numero di righe problematiche e un anteprima delle stesse
    print(f"\n--- DEBUG per {citta} ({periodo}) ---")
    print(f"Numero di righe con 'from_stop_I' non trovato: {len(righe_problematiche)}")
    if not righe_problematiche.empty:
        print("Anteprima delle righe problematiche (mostro le colonne rilevanti):")
        # Seleziona solo le colonne interessanti per non inondare l'output
        print(righe_problematiche[['from_stop_I', 'to_stop_I', 'trip_I', 'route_type']].head(10))

provanan("belfast", path_cartella, "day")
provanan("belfast", path_cartella, "week")  
provanan("berlin", path_cartella, "day")
provanan("berlin", path_cartella, "week")
provanan("luxembourg", path_cartella, "day")
provanan("luxembourg", path_cartella, "week")

##dunque, non mi permette di sapere la localita di questa fermata: viene Nan e va eliminata
##sembra accada principalmente per i file week!


###################### PROVA DI ARCHI ORIENTATI DUPLICATI ###################################

import pandas as pd
import os
from collections import defaultdict

def trova_coppie_duplicate(file):
    
    df = pd.read_csv(file, sep=';')
    
    # Estrai le prime due colonne
    col1, col2 = df.columns[0], df.columns[1]
    coppie = list(zip(df[col1], df[col2]))
    
    # Dizionario per tracciare le coppie e le righe
    mappa_coppie = defaultdict(list)
    
    for idx, coppia in enumerate(coppie):
        mappa_coppie[coppia].append(idx)
    
    # Filtra solo le coppie che appaiono più di una volta
    coppie_duplicate = {coppia: righe for coppia, righe in mappa_coppie.items() if len(righe) > 1}
    
    return coppie_duplicate

trova_coppie_duplicate("C://Users//lucas//Desktop//APPUNTI PROGRAMMAZIONE E ALGORITMI PYTHON//PROGETTO//APADproject//turku//network_temporal_day.csv")

###################################################################################################
##################################################################################################

